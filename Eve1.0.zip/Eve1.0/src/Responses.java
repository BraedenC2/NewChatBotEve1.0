import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Responses extends Main
    {

        public String Responses(String input)
            {
                String response = "";
                input = input.toLowerCase();
                switch (input)
                    {
                        case "hello", "hi", "hey", "howdy":
                            response = "Hi there!";
                            break;
                        case "how are you", "hru", "how r u", "how are u", "how r you", "how you doing":
                            response = "I'm doing good!";
                            break;
                        case "goodbye", "bye", "cya":
                            response = "Goodbye!";
                            break;
                        case "what's up", "sup", "how's it going", "what's new":
                            response = "Not much, just chatting with you!";
                            break;
                        case "tell me a joke", "make me laugh":
                            response = "Sorry, I don't know any.";
                            break;
                        case "what do you like to do", "what are your hobbies":
                            response = "Help you!";
                            break;
                        case "who are you", "what are you", "what do you do":
                            response = "I am Eve.";
                            break;
                        case "thank you", "thanks", "thx":
                            response = "You're welcome!";
                            break;
                        case "what time is it", "what's the time":
                            LocalDateTime now = LocalDateTime.now();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
                            response = "It's currently " + now.format(formatter);
                            break;
                        case "open notes":
                            Notes notes = new Notes();
                            notes.setVisible(true);
                            response = "Here!";
                            break;
                        case "close notes":
                            response = "Click the 'X' in the Notes tab.";
                            break;
                        default:
                            response = "?";
                            break;
                    }
                return response;


            }
    }
