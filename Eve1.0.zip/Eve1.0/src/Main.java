import java.awt.*;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import javax.swing.*;
import javax.swing.GroupLayout;
/*
 * Created on Wed Mar 29 22:45:52 CDT 2023
 */



/**
 * @author Braeden
 */
public class Main extends JFrame {
    public Main() {
        initComponents();
    }

    private void thisComponentResized(ComponentEvent e) {
        // TODO add your code here
        updateLabelFontSize();
    }

    private void textField1(ActionEvent e) {
        // TODO add your code here
        Responses responses = new Responses();
        // Get the user input
        String input = textField1.getText();

        // Generate a response based on the user input
        String response = responses.Responses(input);

        // Update the label with the chatbot's response
        label1.setText(response);

        // Clear the text field for the next user input
        textField1.setText("");

    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents  @formatter:off
        // Generated using JFormDesigner Educational license - Braeden Connors (Braeden C Connors)
        panel1 = new JPanel();
        panel2 = new JPanel();
        label1 = new JLabel();
        textField1 = new JTextField();

        //======== this ========
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                thisComponentResized(e);
            }
        });
        var contentPane = getContentPane();

        //======== panel1 ========
        {
            panel1.setBackground(Color.black);

            //======== panel2 ========
            {
                panel2.setBackground(Color.black);

                //---- label1 ----
                label1.setText("Welcome!");
                label1.setForeground(Color.white);
                label1.setHorizontalTextPosition(SwingConstants.CENTER);
                label1.setHorizontalAlignment(SwingConstants.CENTER);
                label1.setFont(label1.getFont().deriveFont(label1.getFont().getStyle() | Font.BOLD, label1.getFont().getSize() + 30f));
                label1.setBackground(Color.black);

                GroupLayout panel2Layout = new GroupLayout(panel2);
                panel2.setLayout(panel2Layout);
                panel2Layout.setHorizontalGroup(
                    panel2Layout.createParallelGroup()
                        .addComponent(label1, GroupLayout.DEFAULT_SIZE, 753, Short.MAX_VALUE)
                );
                panel2Layout.setVerticalGroup(
                    panel2Layout.createParallelGroup()
                        .addComponent(label1, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
                );
            }

            //---- textField1 ----
            textField1.setBackground(Color.black);
            textField1.setHorizontalAlignment(SwingConstants.CENTER);
            textField1.setForeground(new Color(0x666666));
            textField1.setBorder(BorderFactory.createEmptyBorder());
            textField1.addActionListener(e -> textField1(e));

            GroupLayout panel1Layout = new GroupLayout(panel1);
            panel1.setLayout(panel1Layout);
            panel1Layout.setHorizontalGroup(
                panel1Layout.createParallelGroup()
                    .addComponent(panel2, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(textField1, GroupLayout.DEFAULT_SIZE, 741, Short.MAX_VALUE)
                        .addContainerGap())
            );
            panel1Layout.setVerticalGroup(
                panel1Layout.createParallelGroup()
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(panel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(66, 66, 66)
                        .addComponent(textField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            );
        }

        GroupLayout contentPaneLayout = new GroupLayout(contentPane);
        contentPane.setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(panel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        contentPaneLayout.setVerticalGroup(
            contentPaneLayout.createParallelGroup()
                .addComponent(panel1, GroupLayout.Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        setSize(755, 465);
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents  @formatter:on
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables  @formatter:off
    // Generated using JFormDesigner Educational license - Braeden Connors (Braeden C Connors)
    private JPanel panel1;
    private JPanel panel2;
    private JLabel label1;
    private JTextField textField1;
    // JFormDesigner - End of variables declaration  //GEN-END:variables  @formatter:on

    private void updateLabelFontSize() {
        // Get the current window size
        Dimension windowSize = getSize();
        int width = windowSize.width;
        int height = windowSize.height;

        // Compute the new font size based on the window size
        int newFontSize = (int) (Math.min(width, height) * 0.1);

        // Set the new font size on the label
        label1.setFont(new Font(label1.getFont().getName(), label1.getFont().getStyle(), newFontSize));
    }

    public static void main(String[] args) {
        Main main = new Main();
        main.setDefaultCloseOperation(EXIT_ON_CLOSE);
        main.setVisible(true);
    }


}
